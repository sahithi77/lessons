package controllers;



import org.springframework.web.bind.annotation.RestController;

/**
 * @author Sahithi.Yarrabothula
 *
 */
@RestController
public class MatchInfoController {

	
}
